import { Component } from '@angular/core';

@Component({
  selector: 'app-list-invoices',
  imports: [],
  templateUrl: './list-invoices.html',
  styleUrl: './list-invoices.css'
})
export class ListInvoices {

}
