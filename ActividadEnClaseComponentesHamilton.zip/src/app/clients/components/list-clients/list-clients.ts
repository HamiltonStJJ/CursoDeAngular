import { Component } from '@angular/core';

@Component({
  selector: 'app-list-clients',
  imports: [],
  templateUrl: './list-clients.html',
  styleUrl: './list-clients.css'
})

export class ListClients {

}
