export interface IconInterface {
	name: string,
	path: string
}
