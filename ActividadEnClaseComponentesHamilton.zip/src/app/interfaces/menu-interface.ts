export interface MenuInterface {
	tittle: string,
	url: string,
	icon: string
}
